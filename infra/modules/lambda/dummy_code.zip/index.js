exports.handler = async (event) => { console.log('Hello!'); return { statusCode: 200 }; };
